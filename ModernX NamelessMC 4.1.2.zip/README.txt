* Modernx | NamelessMC *

Template by: Smashino | JTgraphics
Discord ID: Smashino#2202
Discord Link: https://discord.com/invite/trBJjKB - Contact here to receive support
Website: https://jtgraphics.nl


How to install this template:
 
1. Upload ModernX.zip to you file manager at 'custom > templates' and extract files
2. Enable ModernX Template On StaffCP -> Layout -> Templates
3. Logo can be changed using the build in image uploader.
4. Check out 'StaffCP -> Layout -> Templates -> ModernX - Settings' for Discord, Server and layout settings

How to set up navagation:
Navagation is setup so you can are able to display links on the top navbar and on the second navbar.
The top navbar exist of 3 parts, left, mid and right. Use the following priorities for your navagation (StaffCP -> General -> Navagation)
- Left: 1-99
- Mid: 100
- right 101-250

To display links on the second navbar use priorities higher than 251.

To change the custom color:
1. Go to StaffCP -> Layout -> Templates -> ModernX -> Edit -> CSS -> settings.css
2. Change the rgb values on line 27 and 28
3. Save and go to your website
4. CTRL + F5 and purge cache on Cloudflare

DONE!

TOS:
By purchasing this resource, you automatically accept the following conditions. 
Smashino/JTgraphics reserves the right, to change, modify and/or add/remove portions of these Terms and Conditions, at any given time. 
It is the customer's responsibility to check these for changes periodically.

No refunds/chargebacks.
No can not remove copyright rights.
You do not have the rights to share or re-sell this resource.
Resource customization is not included in this resource.
Smashino/JTgraphics reserves the right to revoke you from downloading this theme.
You can not post bad reviews before contacting me.